import UIKit

class Competidor {
    var velocidade: Int
    var aceleracao: Double
    var giro: Double
    var placa: String
    
    init(velocidade: Int, aceleracao: Double, giro: Double, placa: String) {
        self.velocidade = velocidade
        self.aceleracao = aceleracao
        self.giro = giro
        self.placa = placa
    }
}
class Corrida {
    var distancia: Int
    let premioEmDolares: Double
    let nome: String
    var quantidadeDeCompetidoresPermitidos: Int
    var listaDeCompetidores: [Competidor]
    var socorristaCarro: String
    var socorristaMoto: String
    
    init(distancia: Int, premioEmDolares: Double, nome: String, quantidadeDeCompetidoresPermitidos: Int, listaDeCompetidores: [Competidor], socorristaCarro: String, socorristaMoto: String) {
        self.distancia = distancia
        self.premioEmDolares = premioEmDolares
        self.nome = nome
        self.quantidadeDeCompetidoresPermitidos = quantidadeDeCompetidoresPermitidos
        self.listaDeCompetidores = listaDeCompetidores
        self.socorristaCarro = socorristaCarro
        self.socorristaMoto = socorristaMoto
    }
    
    public func adicionarCarro(velocidade: Int , aceleracao: Double, giro: Double, placa: String) -> Void {
        let competidor1 = Competidor(velocidade: velocidade, aceleracao: aceleracao, giro: giro, placa: placa)
        if listaDeCompetidores.count < quantidadeDeCompetidoresPermitidos{
            listaDeCompetidores.append(competidor1)
        }
    }

    public func adicionarMoto(velocidade: Int , aceleracao: Double, giro: Double, placa: String) -> Void {
        let competidor1 = Competidor(velocidade: velocidade, aceleracao: aceleracao, giro: giro, placa: placa)
        if listaDeCompetidores.count <= quantidadeDeCompetidoresPermitidos{
            listaDeCompetidores.append(competidor1)
        }
    }
    
    public func eliminarCompetidor(competidor: Competidor) -> Void {
        let posicao = listaDeCompetidores.firstIndex { (itemCompetidor) -> Bool in
            return itemCompetidor.placa == competidor.placa
        }
        if let index = posicao{
            listaDeCompetidores.remove(at: index)
        }
    }

    public func eliminarCompetidorComPlaca(umaPlaca:String) -> Void {
        let posicao = listaDeCompetidores.firstIndex { (itemCompetidor) -> Bool in
            return itemCompetidor.placa == umaPlaca
        }
        if let index = posicao{
                   listaDeCompetidores.remove(at: index)
        }
    }
        
    public func oGanhador() -> Competidor {
        let posicao = Int.random(in: 0..<listaDeCompetidores.count - 1 )
        return listaDeCompetidores[posicao]
        
        }
        
        public func socorrer(umaPlaca: String) {
            let resultado = listaDeCompetidores.first { (Competidor) -> Bool in
                return umaPlaca == Competidor.placa
            }
            
//            if let competidor = resultado {
//            if competidor is Carro {
//                socorristaCarro.socorrer(umCompetidor:competidor)
//            } else if competidor is Moto {
//                socorristaMoto.socorrer(umCompetidor:competidor)
            }
        }
//    }
//}
class Veiculo: Competidor {
    let peso: Int
    let quantidadeDeRodas: Int
    init(velocidade: Int, aceleracao: Double, giro: Double, placa: String, peso: Int, quantidadeDeRodas: Int) {
        self.peso = peso
        self.quantidadeDeRodas = quantidadeDeRodas
        super.init(velocidade: velocidade, aceleracao: aceleracao, giro: giro, placa: placa)
    }
}

class Carro: Veiculo {
    override init(velocidade: Int, aceleracao: Double, giro: Double, placa: String, peso: Int, quantidadeDeRodas: Int) {
        super.init(velocidade: velocidade, aceleracao: aceleracao, giro: giro, placa: placa, peso: 1000, quantidadeDeRodas: 2)
    }
}
class Moto: Veiculo {
    override init(velocidade: Int, aceleracao: Double, giro: Double, placa: String, peso: Int, quantidadeDeRodas: Int) {
        super.init(velocidade: velocidade, aceleracao: aceleracao, giro: giro, placa: placa, peso: 300, quantidadeDeRodas: 2)
    }
}
        
let moto = Veiculo(velocidade: 357, aceleracao: 326, giro: 3000, placa: "BRA20B1", peso: 300, quantidadeDeRodas: 2)
            
let carro = Veiculo(velocidade: 322, aceleracao: 63.2, giro: 3500, placa: "TNT2A21", peso: 1000, quantidadeDeRodas: 4)

        
class SocorristaCarro : Socorrista {
    func socorrer(UmCompetidor: Competidor) {
        print("Socorrendo carro \(UmCompetidor.placa)")
    }
}
            
class SocorristaMoto : Socorrista {
    func socorrer(UmCompetidor: Competidor) {
        print("Socorrendo moto \(UmCompetidor.placa)")
    }
}

protocol Socorrista {
    func socorrer(UmCompetidor: Competidor)
        }

            


